********************************************************************
******************** 32-bit GPIB Delphi files **********************
********************************************************************

DelphiLI2.exe - self-extracting file for the Delphi Language Interface 
                and the Sample Projects for use with the 32-bit Delphi 
                version 2.0. Included in the self-extracting file:

                * 32-bit Delphi Language Interface
                * A README.TXT file that describes the sample projects
                * Three sample Delphi projects, one using Device-level 
                  NI-488 calls, one using NI-488.2 calls, and one using
                  Asynchronous Event Notification

DelphiLI3.exe - self-extracting file for the Delphi Language Interface 
                and the Sample Projects for use with the 32-bit Delphi 
                version 3.0 or 4.0. Included in the self-extracting 
                file:

                * 32-bit Delphi Language Interface
                * A README.TXT file that describes the sample projects
                * Three sample Delphi projects, one using Device-level 
                  NI-488 calls, one using NI-488.2 calls, and one using
                  Asynchronous Event Notification

delphi32.exe - self-extracting file that contains 8 Direct Entry sample
               programs.

gpibdel2.zip - PKZIP'ed file containing a Direct Entry Windows Sample 
               Program for Win32 using Borland Delphi 2.0. This sample
               is for the Application Note 85.


